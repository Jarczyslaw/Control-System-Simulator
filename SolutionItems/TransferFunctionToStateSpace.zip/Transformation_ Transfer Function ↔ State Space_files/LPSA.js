// Link for topic map
var myMap="http://lpsa.swarthmore.edu/TM/tmExplore/index.html?LPSA";
var myBase="http://lpsa.swarthmore.edu/"

function LPSAPageInfo() {

//Set document title to first H1
var title = document.getElementsByTagName("H1")[0];
if (title) document.title = title.innerHTML;

var myBk=myBase+"images/previous.png";  //Links to images
var myNx=myBase+"images/next.png";
var myNxGray=myBase+"images/nextGray.png";
var myMp=myBase+"images/map.png";
var myMpGray=myBase+"images/mapGray.png";
var myTp=myBase+"images/top.png";
var mySc=myBase+"images/search.png";
var myHp=myBase+"images/info.png";
var mySrch=myBase+"LPSAHelp/LPSA_Search.html";
var myHelp=myBase+"LPSAHelp/LPSA_Help.html";    //Links to help files

//Create Navbar.  Only create myMap button if that variable was declared.
document.writeln("<div class=\"topNavWidget\">");			// This requires LPSACommon.css
document.write("<br /><a href=\"javascript:history.go(-1)\"><img src=" + myBk + " title=\"Back\"></a><br /><br />");	//Back button
document.writeln("<a href=\"javascript:window.scrollTo(0,0)\"><img src=" + myTp +" title=\"Top\"></a><br /><br />");  //Top button
// Next Button (if necessary)
if (window.myNextLink) document.writeln("<a href=" + myNextLink + "><img src=" + myNx + " title=\"Next\"></a><br /><br />");
else  document.writeln("<img src=" + myNxGray + " title=\"unavailable\"></a><br /><br />");
// Map Button (if necesary)
if (window.myMapLink) document.writeln("<a href=" + myMap + "#" + myMapLink + "><img src=" + myMp + " title=\"Topic Map\"></a><br /><br />");
else  document.writeln("<img src=" + myMpGray + " title=\"unavailable\"></a><br /><br />");
document.write("<a href=" + mySrch + "><img src=" + mySc + " title=\"Search\"></a><br /><br />");        //Search
document.write("<a href=" + myHelp + "><img src=" + myHp + " title=\"Help\"></a><br /><br /></div>");    //Help

//Create links
document.write("<a href=\"mailto:echeeve1@swarthmore.edu?subject=");
document.write(document.title);
document.write(" (Comments)\">Comments?</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
document.write("<a href=\"mailto:echeeve1@swarthmore.edu?subject=");
document.write(document.title);
document.write(" (Questions)\">Questions?</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
document.write("<a href=\"mailto:echeeve1@swarthmore.edu?subject=");
document.write(document.title);
document.write(" (Suggestions)\">Suggestions?</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
document.write("<a href=\"mailto:echeeve1@swarthmore.edu?subject=");
document.write(document.title);
document.write(" (Corrections)\">Corrections?</a><br>");

}



